class Msg:
    def __init__(self, code, data='') -> None:
        self.code = code
        self.data = data
